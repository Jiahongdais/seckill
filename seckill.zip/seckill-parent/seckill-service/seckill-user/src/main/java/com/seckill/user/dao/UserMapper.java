package com.seckill.user.dao;
import com.seckill.user.pojo.User;
import tk.mybatis.mapper.common.Mapper;

/****
 * @Author:www.itheima.com
 * @Description:User的Dao
 * @Date  0:12
 *****/
public interface UserMapper extends Mapper<User> {
}
