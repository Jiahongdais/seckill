package com.seckill.goods.dao;
import com.seckill.goods.pojo.UndoLog;
import tk.mybatis.mapper.common.Mapper;

/****
 * @Author:www.itheima.com
 * @Description:UndoLog的Dao
 * @Date  0:12
 *****/
public interface UndoLogMapper extends Mapper<UndoLog> {
}
