package com.seckill.goods.dao;
import com.seckill.goods.pojo.Category;
import tk.mybatis.mapper.common.Mapper;

/****
 * @Author:JHD
 * @Description:Category的Dao
 * @Date  0:12
 *****/
public interface CategoryMapper extends Mapper<Category> {
}
