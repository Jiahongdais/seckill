package com.seckill.goods.dao;
import com.seckill.goods.pojo.SeckillTime;
import tk.mybatis.mapper.common.Mapper;

import java.util.List;

/****
 * @Author:JHD
 * @Description:SeckillTime的Dao
 * @Date  0:12
 *****/
public interface SeckillTimeMapper extends Mapper<SeckillTime> {


}
