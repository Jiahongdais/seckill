package com.seckill.goods.dao;
import com.seckill.goods.pojo.Brand;
import tk.mybatis.mapper.common.Mapper;

/****
 * @Author:JHD
 * @Description:Brand的Dao
 * @Date  0:12
 *****/
public interface BrandMapper extends Mapper<Brand> {
}
