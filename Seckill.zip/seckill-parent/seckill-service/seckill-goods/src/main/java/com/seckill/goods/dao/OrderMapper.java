package com.seckill.goods.dao;
import com.seckill.goods.pojo.Order;
import tk.mybatis.mapper.common.Mapper;

/****
 * @Author:JHD
 * @Description:Order的Dao
 * @Date  0:12
 *****/
public interface OrderMapper extends Mapper<Order> {
}
