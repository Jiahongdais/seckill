package com.seckill.manager.dao;
import com.seckill.manager.pojo.Admin;
import tk.mybatis.mapper.common.Mapper;

/****
 * @Author:JHD
 * @Description:Admin的Dao
 * @Date  0:12
 *****/
public interface AdminMapper extends Mapper<Admin> {
}
